plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.tkamathguard"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.tkamathguard"
        minSdk = 26
        targetSdk = 35
        versionCode = 10
        versionName = "1.0.0-smp"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.ui:ui:1.7.6")
    implementation("androidx.compose.material3:material3:1.3.1")
}
